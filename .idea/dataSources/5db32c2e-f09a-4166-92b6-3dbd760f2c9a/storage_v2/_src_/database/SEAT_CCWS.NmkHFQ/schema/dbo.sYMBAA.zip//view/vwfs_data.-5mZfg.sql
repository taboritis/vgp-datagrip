
-- http://seat.imgproxy.dev.gmind.pl/z6
CREATE VIEW [vwfs_data] AS
SELECT 
	'S' as brand_code,
	mg.carline as model_group_carline,
	mg.name as model_group_name,
	mg.code as model_group_code,
	mg.price as model_group_price,
	mg.model_year as model_group_model_year,
	m.sales_group as model_sales_group,
	m.name as model_name,
	m.code as model_code,
	m.price as model_price,
	m.model_year as model_model_year,
	m.description as model_description,
	'http://seat.imgproxy.dev.gmind.pl/z7' + m.default_image_path + '.png' as model_image,
	'http://seat.imgproxy.dev.gmind.pl/z0' + m.default_image_path + '.png' as model_image_small,
	v.name as version_name,
	v.full_code_ext as version_code,
	v.price as version_price,
	v.description as version_description,
	'http://seat.imgproxy.dev.gmind.pl/z7' + v.default_image_path + '.png' as version_image,
	'http://seat.imgproxy.dev.gmind.pl/z0' + v.default_image_path + '.png' as version_image_small,
	mot.name as motor_name,
	mot.full_code_ext as motor_code,
	mot.price as motor_price,
	mot.type as motor_fuel_type,
	mot.power_ps as motor_power,
	CAST(mot.capacity AS VARCHAR) + ' ' + CAST(mot.type AS VARCHAR) as motor_short_name,
	CAST(t.gears_num AS VARCHAR) + ' biegowa ' + CAST(t.name AS VARCHAR) as motor_transmission_name,
	'http://seat.imgproxy.dev.gmind.pl/z7' + mot.default_image_path + '.png' as motor_image,
	'http://seat.imgproxy.dev.gmind.pl/z0' + mot.default_image_path + '.png' as motor_image_small
  FROM [cache_repository] cr 
  JOIN [model_group] mg on mg.cache_repository_id = cr.id 
  JOIN [model] m on m.model_group_id = mg.id
  JOIN [version] v on v.model_id = m.id
  JOIN [motor] mot on mot.version_id = v.id
  JOIN [transmission] t on t.id = mot.transmission_id
  WHERE cr.is_active = 1

GO

