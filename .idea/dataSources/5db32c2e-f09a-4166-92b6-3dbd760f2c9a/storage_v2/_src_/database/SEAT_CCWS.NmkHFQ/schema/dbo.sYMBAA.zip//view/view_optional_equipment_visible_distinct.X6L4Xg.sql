create VIEW [view_optional_equipment_visible_distinct] AS
SELECT DISTINCT 
	model_group.code AS model_class, 
	model_group.name AS model_name, 
	view_equipment.is_visible, 
	view_equipment.pr_family, 
	view_equipment.short_code, 
	view_equipment.name, 
	view_equipment.description,
	'' as new_name,
	'' as new_description
FROM 
	view_equipment 
JOIN view_motor ON view_equipment.motor_id = view_motor.id
JOIN view_version ON view_motor.version_id = view_version.id
JOIN view_model ON view_version.model_id = view_model.id
JOIN model_group ON view_model.model_group_id = model_group.id
WHERE 
	view_equipment.is_visible = 1
	AND model_group.cache_repository_id=3 
	AND view_equipment.is_option = 1


GO

