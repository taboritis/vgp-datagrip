
CREATE PROCEDURE [dbo].[CreateFinancingImportTables] 
	@StringIds varchar(255)
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @Ids TABLE (
		id int
	)

	INSERT INTO @Ids (id)
	SELECT Data FROM dbo.SplitString(@StringIds,',');

	IF OBJECT_ID('dbo._import_mileage_limit', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_mileage_limit; 

	SELECT ml.*
	INTO _import_mileage_limit
	FROM financing f
	JOIN financing_period fp ON fp.financing_id = f.id
	JOIN mileage_limit ml ON ml.financing_period_id = fp.id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_financing_car_model', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_financing_car_model; 

	SELECT DISTINCT fcm.id, fcm.model_mask
	INTO _import_financing_car_model
	FROM financing f
	JOIN financing_period fp ON fp.financing_id = f.id
	JOIN financing_car_model fcm ON fcm.id = fp.financing_car_model_id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_financing_period', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_financing_period; 

	SELECT fp.*
	INTO _import_financing_period
	FROM financing f
	JOIN financing_period fp ON fp.financing_id = f.id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_initial_payment', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_initial_payment; 

	SELECT ip.*
	INTO _import_initial_payment
	FROM financing f
	JOIN initial_payment ip ON ip.financing_id = f.id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_financing_algorithm', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_financing_algorithm; 

	SELECT DISTINCT fa.id, fa.code
	INTO _import_financing_algorithm
	FROM financing f
	JOIN financing_algorithm fa ON fa.id = f.financing_algorithm_id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_insurance_value', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_insurance_value;

	SELECT DISTINCT iv.*
	INTO _import_insurance_value
	FROM financing f
	JOIN insurance_financing ifi ON ifi.financing_id = f.id
	JOIN insurance i ON i.id = ifi.insurance_id
	JOIN insurance_value iv ON iv.insurance_id = i.id
	WHERE f.id IN (SELECT id FROM @Ids)

	IF OBJECT_ID('dbo._import_insurance', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_insurance;

	SELECT DISTINCT i.*
	INTO _import_insurance
	FROM financing f
	JOIN insurance_financing ifi ON ifi.financing_id = f.id
	JOIN insurance i ON i.id = ifi.insurance_id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_insurance_financing', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_insurance_financing;

	SELECT ifi.*
	INTO _import_insurance_financing
	FROM financing f
	JOIN insurance_financing ifi ON ifi.financing_id = f.id
	WHERE f.id IN (SELECT id FROM @Ids)


	IF OBJECT_ID('dbo._import_financing', 'U') IS NOT NULL 
	  DROP TABLE dbo._import_financing;

	SELECT f.*
	INTO _import_financing
	FROM financing f
	WHERE f.id IN (SELECT id FROM @Ids)
END

GO

