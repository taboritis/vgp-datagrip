
CREATE PROCEDURE [dbo].[ImportFinancing]
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @FinancingId INT
	DECLARE cur SCROLL CURSOR FOR
		SELECT id FROM _import_financing
	OPEN cur;
	FETCH NEXT FROM cur INTO @FinancingId;
	WHILE @@FETCH_STATUS=0
	BEGIN
		INSERT INTO financing (is_active, is_leasing, name, description, commission_rate, credit_insurance_rate, display_netto, display_brutto, is_default, financing_algorithm_id)
		SELECT impf.is_active,
			impf.is_leasing,
			impf.name,
			impf.description,
			impf.commission_rate,
			impf.credit_insurance_rate,
			impf.display_netto,
			impf.display_brutto,
			impf.is_default,
			fa.id
		FROM _import_financing impf
		JOIN _import_financing_algorithm impfa ON impfa.id = impf.financing_algorithm_id
		JOIN financing_algorithm fa ON fa.code = impfa.code
		WHERE impf.id = @FinancingId

		INSERT INTO dbo.#Financing (import_id, new_id) VALUES (@FinancingId, SCOPE_IDENTITY())
		
		FETCH NEXT FROM cur INTO @FinancingId;
	END
	CLOSE cur
	DEALLOCATE cur
END

GO

