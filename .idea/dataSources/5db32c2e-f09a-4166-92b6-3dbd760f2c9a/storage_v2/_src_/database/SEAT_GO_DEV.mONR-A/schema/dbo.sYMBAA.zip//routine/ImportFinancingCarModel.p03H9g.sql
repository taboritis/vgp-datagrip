
CREATE PROCEDURE [dbo].[ImportFinancingCarModel] 
AS
BEGIN
	SET NOCOUNT ON;

    INSERT INTO financing_car_model (model_mask)
    SELECT impfcm.model_mask
	FROM _import_financing_car_model impfcm
	LEFT JOIN financing_car_model fcm ON fcm.model_mask = impfcm.model_mask
	WHERE fcm.id IS NULL
END

GO

