
CREATE PROCEDURE [dbo].[ImportMileageLimit]
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO mileage_limit (financing_period_id, value, isDefault, rv_rate)
	SELECT fp.id, impml.value, impml.isDefault, impml.rv_rate
	FROM _import_mileage_limit impml
	JOIN _import_financing_period impfp ON impfp.id = impml.financing_period_id
	JOIN dbo.#Financing tmpf ON tmpf.import_id = impfp.financing_id
	JOIN _import_financing_car_model impfcm ON impfcm.id = impfp.financing_car_model_id
	JOIN financing_car_model fcm ON fcm.model_mask = impfcm.model_mask
	JOIN financing_period fp ON fp.value = impfp.value
		AND fp.financing_id = tmpf.new_id
		AND fp.financing_car_model_id = fcm.id
END

GO

