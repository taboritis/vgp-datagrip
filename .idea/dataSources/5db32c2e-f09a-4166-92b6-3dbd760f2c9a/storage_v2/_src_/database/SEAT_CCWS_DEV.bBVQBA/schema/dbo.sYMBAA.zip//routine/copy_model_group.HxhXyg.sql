CREATE PROCEDURE [dbo].[copy_model_group] @sourceCacheRepositoryId INT
	,@carline INT
	,@targetCacheRepositoryId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Copy model group
	INSERT INTO [dbo].[model_group] (
		[cache_repository_id]
		,[carline]
		,[local_id]
		,[model_year]
		,[list_order]
		,[name]
		,[code]
		,[price]
		,[is_visible]
		,[start_date]
		,[dataUpdateDate]
		,[priceUpdateDate]
		)
	SELECT @targetCacheRepositoryId
		,[carline]
		,[local_id]
		,[model_year]
		,[list_order]
		,[name]
		,[code]
		,[price]
		,[is_visible]
		,[start_date]
		,[dataUpdateDate]
		,[priceUpdateDate]
	FROM [dbo].[model_group] mg
	WHERE [cache_repository_id] = @sourceCacheRepositoryId
		AND [carline] = @carline AND NOT EXISTS (
			SELECT id FROM [model_group] mg_target WHERE mg_target.carline = @carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
		)

	-- copy transmission
	INSERT INTO [dbo].[transmission]
           ([model_group_id]
           ,[gears_num]
           ,[code]
           ,[name]
           ,[is_automatic])
	SELECT 
			mg_target.[id]
			,t.[gears_num]
			,t.[code]
			,t.[name]
			,t.[is_automatic]
	FROM [dbo].[model_group] mg
	JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	JOIN [dbo].[transmission] t ON t.model_group_id = mg.id
	WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline

	-- copy exterior group
	INSERT INTO [dbo].[exterior_group]
           ([cache_repository_id]
           ,[code]
           ,[list_order]
           ,[name]
           ,[is_visible])
	 SELECT @targetCacheRepositoryId
			,[code]
			,[list_order]
			,[name]
			,[is_visible]
		FROM  [dbo].[exterior_group] eg
		WHERE NOT EXISTS (
			SELECT id FROM [exterior_group] eg_target WHERE eg_target.code = eg.code AND eg_target.cache_repository_id = @targetCacheRepositoryId
		) AND eg.cache_repository_id = @sourceCacheRepositoryId

	-- copy interior group
	INSERT INTO [dbo].[interior_group]
           ([cache_repository_id]
           ,[code]
           ,[list_order]
           ,[name]
           ,[is_visible])
	 SELECT @targetCacheRepositoryId
			,[code]
			,[list_order]
			,[name]
			,[is_visible]
		FROM  [dbo].[interior_group] ig
		WHERE NOT EXISTS (
			SELECT id FROM [interior_group] ig_target WHERE ig_target.code = ig.code AND ig_target.cache_repository_id = @targetCacheRepositoryId
		) AND ig.cache_repository_id = @sourceCacheRepositoryId

	-- copy equipment group
	INSERT INTO [dbo].[equipment_group]
           ([cache_repository_id]
           ,[code]
           ,[name]
           ,[list_order]
           ,[is_visible])
	 SELECT @targetCacheRepositoryId
			,[code]
			,[name]
			,[list_order]
			,[is_visible]
		FROM  [dbo].[equipment_group] eg
		WHERE NOT EXISTS (
			SELECT id FROM [equipment_group] eg_target WHERE eg_target.code = eg.code AND eg_target.cache_repository_id = @targetCacheRepositoryId
		) AND eg.cache_repository_id = @sourceCacheRepositoryId

	-- copy models
	INSERT INTO [dbo].[model]
           ([model_group_id]
           ,[sales_group]
           ,[local_id]
           ,[model_year]
           ,[list_order]
           ,[code]
           ,[short_code]
           ,[name]
           ,[price]
           ,[is_default]
           ,[is_visible]
           ,[start_date]
           ,[description]
           ,[end_date]
           ,[default_image_path])
	SELECT mg_target.id
		  ,m.[sales_group]
		  ,m.[local_id]
		  ,m.[model_year]
		  ,m.[list_order]
		  ,m.[code]
		  ,m.[short_code]
		  ,m.[name]
		  ,m.[price]
		  ,m.[is_default]
		  ,m.[is_visible]
		  ,m.[start_date]
		  ,m.[description]
		  ,m.[end_date]
		  ,m.[default_image_path]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [model] m_target WHERE m_target.sales_group = m.sales_group AND m_target.model_group_id = mg_target.id
		)

	-- copy versions
	INSERT INTO [dbo].[version]
           ([model_id]
           ,[list_order]
           ,[code]
           ,[full_code]
           ,[full_code_ext]
           ,[local_id]
           ,[action_code]
           ,[name]
           ,[price]
           ,[is_default]
           ,[is_visible]
           ,[start_date]
           ,[description]
           ,[default_image_path])
	SELECT 
		  m_target.id
		  ,v.[list_order]
		  ,v.[code]
		  ,v.[full_code]
		  ,v.[full_code_ext]
		  ,v.[local_id]
		  ,v.[action_code]
		  ,v.[name]
		  ,v.[price]
		  ,v.[is_default]
		  ,v.[is_visible]
		  ,v.[start_date]
		  ,v.[description]
		  ,v.[default_image_path]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [version] v_target WHERE v_target.full_code_ext = v.full_code_ext AND v_target.model_id = m_target.id
		)


	-- copy motors
	INSERT INTO [dbo].[motor]
			   ([version_id]
			   ,[transmission_id]
			   ,[price_type]
			   ,[spec_version]
			   ,[list_order]
			   ,[is_default]
			   ,[is_visible]
			   ,[is_diesel]
			   ,[price_group]
			   ,[code]
			   ,[full_code]
			   ,[full_code_ext]
			   ,[full_code_version_ext]
			   ,[local_id]
			   ,[name]
			   ,[start_date]
			   ,[capacity]
			   ,[type]
			   ,[power_ps]
			   ,[power_kw]
			   ,[attributes]
			   ,[price]
			   ,[default_image_path]
			   ,[model_year])
	SELECT v_target.id
		  ,t_target.id
		  ,mot.[price_type]
		  ,mot.[spec_version]
		  ,mot.[list_order]
		  ,mot.[is_default]
		  ,mot.[is_visible]
		  ,mot.[is_diesel]
		  ,mot.[price_group]
		  ,mot.[code]
		  ,mot.[full_code]
		  ,mot.[full_code_ext]
		  ,mot.[full_code_version_ext]
		  ,mot.[local_id]
		  ,mot.[name]
		  ,mot.[start_date]
		  ,mot.[capacity]
		  ,mot.[type]
		  ,mot.[power_ps]
		  ,mot.[power_kw]
		  ,mot.[attributes]
		  ,mot.[price]
		  ,mot.[default_image_path]
		  ,mot.[model_year]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[transmission] t ON t.id = mot.transmission_id
	  JOIN [dbo].[transmission] t_target ON t_target.model_group_id = mg_target.id AND t_target.code = t.code
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [motor] mot_target WHERE mot_target.full_code_ext = mot.full_code_ext AND mot_target.version_id = v_target.id
		)

	-- copy equipment
	INSERT INTO [dbo].[equipment]
           ([motor_id]
           ,[equipment_group_id]
           ,[code]
           ,[local_id]
           ,[full_code_ext]
           ,[short_code]
           ,[pr_family]
           ,[name]
           ,[description]
           ,[list_order]
           ,[is_package]
           ,[is_promo]
           ,[is_standard]
           ,[is_option]
           ,[is_visible]
           ,[is_recommended]
           ,[price_promo]
           ,[price]
           ,[price_type]
           ,[price_group]
           ,[image_path])
	SELECT mot_target.id
      ,eg_target.id
      ,eq.[code]
      ,eq.[local_id]
      ,eq.[full_code_ext]
      ,eq.[short_code]
      ,eq.[pr_family]
      ,eq.[name]
      ,eq.[description]
      ,eq.[list_order]
      ,eq.[is_package]
      ,eq.[is_promo]
      ,eq.[is_standard]
      ,eq.[is_option]
      ,eq.[is_visible]
      ,eq.[is_recommended]
      ,eq.[price_promo]
      ,eq.[price]
      ,eq.[price_type]
      ,eq.[price_group]
      ,eq.[image_path]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[equipment] eq ON eq.motor_id = mot.id
	  LEFT JOIN [dbo].[equipment_group] eg ON eq.equipment_group_id = eg.id
	  LEFT JOIN [dbo].[equipment_group] eg_target ON eg_target.code = eg.code AND eg.cache_repository_id = @targetCacheRepositoryId
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [equipment] eq_target WHERE eq_target.full_code_ext = eq.full_code_ext AND eq_target.motor_id = mot_target.id
		)

	-- copy version extensions
	INSERT INTO [dbo].[version_extension]
			   ([version_id]
			   ,[equipment_id])
	SELECT v_target.id 
		,eq_target.id
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[equipment] eq ON eq.motor_id = mot.id
	  JOIN [dbo].[equipment] eq_target ON eq_target.motor_id = mot_target.id AND eq_target.full_code_ext = eq.full_code_ext
	  JOIN [dbo].[version_extension] vext ON vext.version_id = v.id AND vext.equipment_id = eq.id
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT vext.equipment_id FROM [version_extension] vext_target WHERE vext_target.equipment_id = eq_target.id AND vext_target.version_id = v_target.id
		)

	-- copy exteriors
	INSERT INTO [dbo].[exterior]
           ([motor_id]
           ,[exterior_group_id]
           ,[list_order]
           ,[code]
           ,[full_code_ext]
           ,[name]
           ,[price]
           ,[price_type]
           ,[price_group]
           ,[is_default]
           ,[is_visible]
           ,[local_id]
           ,[default_image_path])
	SELECT mot_target.id
      ,eg_target.id
      ,ext.[list_order]
      ,ext.[code]
      ,ext.[full_code_ext]
      ,ext.[name]
      ,ext.[price]
      ,ext.[price_type]
      ,ext.[price_group]
      ,ext.[is_default]
      ,ext.[is_visible]
      ,ext.[local_id]
      ,ext.[default_image_path]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[exterior] ext ON ext.motor_id = mot.id
	  LEFT JOIN [dbo].[exterior_group] eg ON ext.exterior_group_id = eg.id
	  LEFT JOIN [dbo].[exterior_group] eg_target ON eg_target.cache_repository_id = @targetCacheRepositoryId AND eg_target.code = eg.code
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [exterior] ext_target WHERE ext_target.full_code_ext = ext.full_code_ext AND ext_target.motor_id = mot_target.id
		)

	-- copy interiors
	INSERT INTO [dbo].[interior]
           ([motor_id]
           ,[interior_group_id]
           ,[list_order]
           ,[code]
           ,[full_code_ext]
           ,[name]
           ,[price]
           ,[local_id]
           ,[is_default]
           ,[is_visible]
           ,[default_image_path]
           ,[equipment_extension_id])
	SELECT mot_target.id
      ,ig_target.id
      ,inte.[list_order]
      ,inte.[code]
      ,inte.[full_code_ext]
      ,inte.[name]
      ,inte.[price]
      ,inte.[local_id]
      ,inte.[is_default]
      ,inte.[is_visible]
      ,inte.[default_image_path]
      ,eq_ext_target.id
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[interior] inte ON inte.motor_id = mot.id
	  LEFT JOIN [dbo].[equipment] eq_ext ON eq_ext.id = inte.equipment_extension_id
	  LEFT JOIN [dbo].[equipment] eq_ext_target ON eq_ext_target.motor_id = mot_target.id AND eq_ext_target.full_code_ext = eq_ext.full_code_ext
	  LEFT JOIN [dbo].[interior_group] ig ON ig.id = inte.interior_group_id
	  LEFT JOIN [dbo].[interior_group] ig_target ON ig_target.cache_repository_id = @targetCacheRepositoryId AND ig_target.code = ig.code
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [interior] inte_target WHERE inte_target.full_code_ext = inte.full_code_ext AND inte_target.motor_id = mot_target.id
		)

	-- copy equipment-equipment relation
	INSERT INTO [dbo].[equipment_equipment_relation]
           ([child_equipment_id]
           ,[parent_equipment_id])
	SELECT eq_target.id
		,eq_parent_target.id
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[equipment] eq ON eq.motor_id = mot.id
	  JOIN [dbo].[equipment] eq_target ON eq_target.motor_id = mot_target.id AND eq_target.full_code_ext = eq.full_code_ext
	  JOIN [dbo].[equipment_equipment_relation] eer ON eer.child_equipment_id = eq.id
	  JOIN [dbo].[equipment] eq_parent ON eer.parent_equipment_id = eq_parent.id
	  JOIN [dbo].[equipment] eq_parent_target ON eq_parent_target.motor_id = mot_target.id AND eq_parent_target.full_code_ext = eq_parent.full_code_ext	  
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT parent_equipment_id FROM [equipment_equipment_relation] eer_target WHERE eer_target.child_equipment_id = eq_target.id AND eer_target.parent_equipment_id = eq_parent_target.id
		)



	-- copy technical data
	INSERT INTO [dbo].[technical_data]
           ([technical_data_definition_id]
           ,[motor_id]
           ,[value]
           ,[isDeleted])
	SELECT td.[technical_data_definition_id]
      ,mot_target.id
      ,td.[value]
      ,td.[isDeleted]
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[technical_data] td ON td.motor_id = mot.id
	  JOIN [dbo].[technical_data_definition] tdd ON tdd.id = td.technical_data_definition_id
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT id FROM [technical_data] td_target WHERE td_target.motor_id = mot_target.id AND td_target.technical_data_definition_id = td.technical_data_definition_id
		)

	-- copy equipment price rules
	INSERT INTO [dbo].[equipment_price_rule]
           ([base_equipment_id]
           ,[first_associated_equipment_id]
           ,[second_associated_equipment_id]
           ,[price])
	SELECT eq_target.id
		,eq_ass1_target.id
		,eq_ass2_target.id
		,epr.price
	  FROM [dbo].[model_group] mg	
	  JOIN [dbo].[model_group] mg_target ON mg_target.carline = mg.carline AND mg_target.cache_repository_id = @targetCacheRepositoryId
	  JOIN [dbo].[model] m ON m.model_group_id = mg.id
	  JOIN [dbo].[model] m_target ON m_target.model_group_id = mg_target.id AND m_target.sales_group = m.sales_group
	  JOIN [dbo].[version] v ON v.model_id = m.id
	  JOIN [dbo].[version] v_target ON v_target.model_id = m_target.id AND v_target.full_code_ext = v.full_code_ext
	  JOIN [dbo].[motor] mot ON mot.version_id = v.id
	  JOIN [dbo].[motor] mot_target ON mot_target.version_id = v_target.id AND mot_target.full_code_ext = mot.full_code_ext
	  JOIN [dbo].[equipment] eq ON eq.motor_id = mot.id
	  JOIN [dbo].[equipment] eq_target ON eq_target.motor_id = mot_target.id AND eq_target.full_code_ext = eq.full_code_ext
	  JOIN [dbo].[equipment_price_rule] epr ON epr.base_equipment_id = eq.id
	  JOIN [dbo].[equipment] eq_ass1 ON epr.first_associated_equipment_id = eq_ass1.id
	  JOIN [dbo].[equipment] eq_ass1_target ON eq_ass1_target.motor_id = mot_target.id AND eq_ass1_target.full_code_ext = eq_ass1.full_code_ext	  
	  LEFT JOIN [dbo].[equipment] eq_ass2 ON epr.second_associated_equipment_id = eq_ass2.id
	  LEFT JOIN [dbo].[equipment] eq_ass2_target ON eq_ass2_target.motor_id = mot_target.id AND eq_ass2_target.full_code_ext = eq_ass2.full_code_ext	  
	  WHERE mg.[cache_repository_id] = @sourceCacheRepositoryId
		AND mg.[carline] = @carline 
		AND NOT EXISTS (
			SELECT base_equipment_id FROM [equipment_price_rule] epr_target 
			WHERE epr_target.base_equipment_id = eq_target.id 
				AND epr_target.first_associated_equipment_id = eq_ass1_target.id
				AND (epr_target.second_associated_equipment_id = eq_ass2_target.id OR (eq_ass2_target.id IS NULL AND epr_target.second_associated_equipment_id IS NULL))
		)
END
GO

