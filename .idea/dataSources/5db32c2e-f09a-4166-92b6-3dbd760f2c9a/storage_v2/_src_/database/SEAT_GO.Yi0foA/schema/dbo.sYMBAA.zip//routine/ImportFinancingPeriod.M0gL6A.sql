
CREATE PROCEDURE [dbo].[ImportFinancingPeriod]
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO financing_period (financing_id, financing_car_model_id, isDefault, value, interest_rate, final_value_rate)
    SELECT tmpf.new_id,
		MAX(fcm.id),
		impfp.isDefault,
		impfp.value,
		impfp.interest_rate,
		impfp.final_value_rate
	FROM _import_financing_period impfp
	JOIN dbo.#Financing tmpf ON tmpf.import_id = impfp.financing_id
	JOIN _import_financing_car_model impfcm ON impfcm.id = impfp.financing_car_model_id
	JOIN financing_car_model fcm ON fcm.model_mask = impfcm.model_mask
	GROUP BY tmpf.new_id, impfp.isDefault, impfp.value, impfp.interest_rate, impfp.final_value_rate, fcm.model_mask
END

GO

