-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[get_new_leads_offers_base_week]
(	
	@Year int,
	@Week int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT *, 'leads' as value_type
	FROM (
		SELECT CAST(@Week as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_leads
		FROM get_new_leads_base_week (@Year, @Week) nle
		UNION ALL
		SELECT CAST(@Week + 1 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_leads
		FROM get_new_leads_base_week (@Year, @Week + 1) nle
		UNION ALL
		SELECT CAST(@Week + 2 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_leads
		FROM get_new_leads_base_week (@Year, @Week + 2) nle
		UNION ALL
		SELECT CAST(@Week + 3 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_leads
		FROM get_new_leads_base_week (@Year, @Week + 3) nle
	) x
	PIVOT (
		SUM(x.number_of_leads) FOR model IN (A1, A3, [A3 Limousine], A4, A5, A6, A7, A8, Q3, Q5, Q7, R8, TT, Total)
	) p
	UNION ALL
	SELECT *, 'offers' as value_type
	FROM (
		SELECT CAST(@Week as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_offers
		FROM get_offers_base_week (@Year, @Week) nle
		UNION ALL
		SELECT CAST(@Week + 1 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_offers
		FROM get_offers_base_week (@Year, @Week + 1) nle
		UNION ALL
		SELECT CAST(@Week + 2 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_offers
		FROM get_offers_base_week (@Year, @Week + 2) nle
		UNION ALL
		SELECT CAST(@Week + 3 as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,nle.model
			,nle.number_of_offers
		FROM get_offers_base_week (@Year, @Week + 3) nle
	) x
	PIVOT (
		SUM(x.number_of_offers) FOR model IN (A1, A3, [A3 Limousine], A4, A5, A6, A7, A8, Q3, Q5, Q7, R8, TT, Total)
	) p
)
GO

