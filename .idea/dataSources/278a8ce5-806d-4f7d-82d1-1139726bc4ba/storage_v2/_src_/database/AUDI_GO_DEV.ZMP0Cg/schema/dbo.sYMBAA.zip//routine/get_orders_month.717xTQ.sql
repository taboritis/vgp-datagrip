
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[get_offers2]
(	
	@Year int,
	@Month int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT model, COUNT(1) as number_of_offers
	FROM (
		SELECT x.model, x.offer_id
		FROM (
			SELECT dbo.model_code_to_model2(c.model_code) as model
				,o.customer_id as customer_id
				,o.id as offer_id
				,o.finished_date as finished_date
			FROM configuration c
			JOIN calculation cl on cl.configuration_id = c.id
			JOIN offer o ON o.id = c.offer_id
			WHERE o.finished_date IS NOT NULL AND o.order_download = 1
		) x
		WHERE x.model IS NOT NULL AND x.customer_id IS NOT NULL AND YEAR(x.finished_date) = @Year AND MONTH(x.finished_date) = @Month
		GROUP BY x.model, x.offer_id
	) y
	GROUP BY y.model
	
	UNION ALL
	
	SELECT 'Total', COUNT(1)
	FROM (
		SELECT x.offer_id
		FROM (
			SELECT dbo.model_code_to_model2(c.model_code) as model
				,o.customer_id as customer_id
				,o.id as offer_id
				,o.finished_date as finished_date
			FROM configuration c
			JOIN calculation cl on cl.configuration_id = c.id
			JOIN offer o ON o.id = c.offer_id
			WHERE o.finished_date IS NOT NULL AND o.order_download = 1
		) x
		WHERE x.model IS NOT NULL AND x.customer_id IS NOT NULL AND YEAR(x.finished_date) = @Year AND MONTH(x.finished_date) = @Month
		GROUP BY x.offer_id
	) y
)

GO

