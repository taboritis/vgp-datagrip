CREATE VIEW dbo.lost_packages
AS
SELECT DISTINCT 
                      TOP (100) PERCENT e1.model_year, e1.model_code, e1.equipment_code, e1.pr, e1.pr2, e1.pr3, e1.price AS old_price, e2.price AS new_price, 
                      e1.date_start AS old_date_start, e1.date_end AS old_date_end, e2.date_start AS new_date_start, e2.date_end AS new_date_end, e1.type AS old_flag, 
                      e2.type AS new_flag, e2.created AS new_created, e2.id AS new_id
FROM         dbo.cis_equipment_price AS e1 INNER JOIN
                      dbo.cis_equipment_price AS e2 ON e1.equipment_code = e2.equipment_code AND e1.model_code = e2.model_code AND e1.model_year = e2.model_year AND 
                      e1.date_start < e2.date_start AND e1.type <> e2.type
WHERE     (e1.type = 'P') AND (e2.type <> 'C') AND (e2.date_end IS NULL)
ORDER BY e1.model_year, e1.model_code, e1.equipment_code, new_date_start, new_date_end DESC, new_created
GO

