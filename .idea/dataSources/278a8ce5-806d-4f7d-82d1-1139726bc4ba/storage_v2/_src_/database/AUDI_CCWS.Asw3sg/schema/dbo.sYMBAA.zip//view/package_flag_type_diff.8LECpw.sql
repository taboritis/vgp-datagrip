/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.package_flag_type_diff
AS
SELECT     TOP (100) PERCENT LEFT(model_code, 3) AS model_group, equipment_code, MIN(LEFT(CONVERT(VARCHAR, created, 121), 19) + '-' + type) AS min_created_type, 
                      MAX(LEFT(CONVERT(VARCHAR, created, 121), 19) + '-' + type) AS max_created_type
FROM         dbo.cis_equipment_price
GROUP BY LEFT(model_code, 3), equipment_code
HAVING      (COUNT(equipment_code) > 1) AND (MIN(type) <> MAX(type)) AND (RIGHT(MIN(LEFT(CONVERT(VARCHAR, created, 121), 19) + '-' + type), 1) 
                      <> RIGHT(MAX(LEFT(CONVERT(VARCHAR, created, 121), 19) + '-' + type), 1)) AND (RIGHT(MAX(LEFT(CONVERT(VARCHAR, created, 121), 19) + '-' + type), 1) <> 'P') AND 
                      (MAX(type) = 'P')
ORDER BY model_group, equipment_code
GO

