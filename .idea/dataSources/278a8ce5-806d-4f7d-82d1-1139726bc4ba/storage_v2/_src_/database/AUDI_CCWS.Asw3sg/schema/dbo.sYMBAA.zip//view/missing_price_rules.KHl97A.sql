CREATE VIEW dbo.missing_price_rules
AS
select p1.*
from (SELECT A.model_code, A.model_year, A.equipment_code as package_code, A.includes, a.value('.', 'VARCHAR(100)') AS equipment_code 
     FROM  
     (
          SELECT p.id,p.equipment_code, p.includes, p.model_code, p.model_year,
              CAST ('<M>' + REPLACE(p.includes, ',', '</M><M>') + '</M>' AS XML) AS equipment_codes  
          FROM cis_equipment_include_def p
          
          ) AS A CROSS APPLY equipment_codes.nodes ('/M') AS Split(a)
     ) p1
     left JOIN cis_equipment_price pp ON pp.equipment_code = p1.equipment_code AND pp.type = 'C' and p1.model_code = pp.model_code and p1.model_year = pp.model_year
     where pp.id is null
     group by  p1.package_code, p1.model_code, p1.model_year,  p1.equipment_code, includes
GO

