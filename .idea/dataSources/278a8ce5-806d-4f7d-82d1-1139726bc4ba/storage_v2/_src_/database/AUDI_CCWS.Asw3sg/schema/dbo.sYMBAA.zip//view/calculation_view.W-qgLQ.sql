CREATE VIEW dbo.calculation_view
AS
SELECT  eq.id,
                eq.code,
                eq.name,
cf.kt, cf.audi_code,                
CASE WHEN eq.mbv_flag = 'P' THEN 'C' ELSE ep2.type END as type,
                CASE
            WHEN eq.mbv_flag = 'P' THEN 0    
			WHEN ep2.price IS NOT NULL THEN ep2.price
			WHEN eg.id IS NOT NULL THEN
				(SELECT top 1 ISNULL(p.price, eq.price)
					FROM cis_exterior_price p
				 WHERE p.model_code = SUBSTRING(cf.model_original_code, 1, 6)
					 AND p.model_year = cf.model_year
					 AND p.exterior_code = RIGHT(eq.original_code, 4)
					 AND (p.pr IS NULL OR p.pr IS NOT NULL AND p.pr IN (select e.code from equipment e where e.configuration_id = cf.id))
					 AND (p.pr2 IS NULL OR p.pr2 IS NOT NULL AND p.pr2 IN (select e.code from equipment e where e.configuration_id = cf.id))
					 AND p.date_start <= GETDATE()
					 AND (p.date_end IS null OR p.date_end >= GETDATE())
					 ORDER BY Rank() over (Partition by p.exterior_code Order by p.pr2, p.pr) desc)
			END as price,
		CASE
                    WHEN ep.type = 'E' THEN ep.price
                    WHEN ep.type = 'P' THEN (
                        select SUM(price)
                        from (SELECT A.id, A.model_code, A.model_year, Split.a.value('.', 'VARCHAR(100)') AS equipment_code 
                             FROM  
                             (
                                  SELECT p.id, p.model_code, p.model_year,
                                      CAST ('<M>' + REPLACE(p.includes, ',', '</M><M>') + '</M>' AS XML) AS equipment_codes  
                                  FROM cis_equipment_include_def p
                                  WHERE p.model_code = ep.model_code
                                     AND p.model_year = ep.model_year
                                     AND p.equipment_code = ep.equipment_code
                                     AND p.date_start <= GETDATE()
                                     AND (p.date_end IS null OR p.date_end >= GETDATE())
                                  ) AS A CROSS APPLY equipment_codes.nodes ('/M') AS Split(a)
                             ) p1
                             JOIN cis_equipment_price pp ON pp.equipment_code = p1.equipment_code AND pp.type = 'E' AND pp.date_start <= GETDATE() 
                             AND (pp.date_end IS null OR pp.date_end >= GETDATE()) and pp.id = (
                                 select TOP 1 id 
                                 from cis_equipment_price pp2 
                                 where pp2.model_year = p1.model_year
                                    AND pp2.equipment_code = pp.equipment_code
                                    AND pp2.model_code = SUBSTRING(p1.model_code, 1, 6) 
                                    AND pp2.date_start <= GETDATE()
                                    AND (pp2.date_end IS null OR pp2.date_end >= GETDATE())
                                    AND pp2.type = 'E'
                                    AND (pp2.pr IS NULL OR pp2.pr IS NOT NULL AND pp2.pr IN (select e1.code from equipment e1 where e1.configuration_id = cf.id))
                                    AND (pp2.pr2 IS NULL OR pp2.pr2 IS NOT NULL AND pp2.pr2 IN (select e2.code from equipment e2 where e2.configuration_id = cf.id))
                                    AND (pp2.pr3 IS NULL OR pp2.pr3 IS NOT NULL AND pp2.pr3 IN (select e3.code from equipment e3 where e3.configuration_id = cf.id)) 
                                    ORDER BY Rank() over (Partition by pp2.equipment_code Order by pp2.pr3, pp2.pr2, pp2.pr) desc)
                             )
                END as base_price,
                CASE
                    WHEN ep.type = 'P' THEN (
                        SELECT TOP 1 p.includes
                         FROM cis_equipment_include_def p
                         WHERE p.model_code = ep.model_code
                           AND p.model_year = ep.model_year
                           AND p.equipment_code = ep.equipment_code
                           AND p.date_start <= GETDATE()
                           AND (p.date_end IS null OR p.date_end >= GETDATE())

                    ) else  NULL
                END as includes                          
             FROM configuration cf
             JOIN equipment eq 
                  ON eq.configuration_id = cf.id 
                 AND eq.is_standard = 0 and eq.is_included = 0
             LEFT JOIN equipment_group eg 
                  ON eq.equipment_group_id = eg.id 
                 AND eg.family_id IN ('colors.exterior', 'weitere.weitere')
             LEFT JOIN cis_equipment_price ep 
                 ON ep.id = (
                  select TOP 1 id 
                  from cis_equipment_price ep4
                  where ep4.equipment_code = eq.code 
                     AND ep4.model_year = cf.model_year 
                     AND ep4.model_code = SUBSTRING(cf.model_original_code, 1, 6) 
                     AND ep4.date_start <= GETDATE()
                     AND (ep4.date_end IS null OR ep4.date_end >= GETDATE())
                     AND (ep4.pr IS NULL OR ep4.pr IS NOT NULL AND ep4.pr IN (select e.code from equipment e where e.configuration_id = cf.id))
                     AND (ep4.pr2 IS NULL OR ep4.pr2 IS NOT NULL AND ep4.pr2 IN (select e.code from equipment e where e.configuration_id = cf.id))
                     AND (ep4.pr3 IS NULL OR ep4.pr3 IS NOT NULL AND ep4.pr3 IN (select e.code from equipment e where e.configuration_id = cf.id)) 
                     AND ep4.type IN ('E', 'P')
                     ORDER BY Rank() over (Partition by eq.code ORDER BY LEN(ISNULL(ep4.pr3, '') + ISNULL(ep4.pr2, '') + ISNULL(ep4.pr, '')) desc, CASE WHEN type = 'P' THEN 1 WHEN type = 'C' THEN 2 ELSE 3 END))
             LEFT JOIN cis_equipment_price ep2
                  ON ep2.id = (
                  select TOP 1 id 
                  from cis_equipment_price ep3 
                  where ep3.equipment_code = eq.code 
                     AND ep3.model_year = cf.model_year 
                     AND ep3.model_code = SUBSTRING(cf.model_original_code, 1, 6) 
                     AND ep3.date_start <= GETDATE()
                     AND (ep3.date_end IS null OR ep3.date_end >= GETDATE())
                     AND (ep3.pr IS NULL OR ep3.pr IS NOT NULL AND ep3.pr IN (select e.code from equipment e where e.configuration_id = cf.id))
                     AND (ep3.pr2 IS NULL OR ep3.pr2 IS NOT NULL AND ep3.pr2 IN (select e.code from equipment e where e.configuration_id = cf.id))
                     AND (ep3.pr3 IS NULL OR ep3.pr3 IS NOT NULL AND ep3.pr3 IN (select e.code from equipment e where e.configuration_id = cf.id)) 
                     ORDER BY Rank() over (Partition by ep3.equipment_code ORDER BY LEN(ISNULL(ep3.pr3, '') + ISNULL(ep3.pr2, '') + ISNULL(ep3.pr, '')) desc, CASE WHEN type = 'P' THEN 1 WHEN type = 'C' THEN 2 ELSE 3 END))
GO

EXEC sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'calculation_view'
GO

EXEC sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'calculation_view'
GO

