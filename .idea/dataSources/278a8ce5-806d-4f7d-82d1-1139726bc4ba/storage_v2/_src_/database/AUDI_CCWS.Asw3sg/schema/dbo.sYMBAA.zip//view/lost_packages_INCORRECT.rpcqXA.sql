CREATE VIEW dbo.lost_packages
AS
SELECT     e1.id, e1.date_start, e1.date_end, e1.model_code, e1.model_year, e1.equipment_code, e1.type AS old_flag, e1.pr, e1.pr2, e1.pr3, e1.created, e1.price, 
                      e2.type AS new_flag
FROM         dbo.cis_equipment_price AS e1 INNER JOIN
                      dbo.cis_equipment_price AS e2 ON e1.equipment_code = e2.equipment_code AND e1.model_code = e2.model_code AND e1.model_year = e2.model_year AND 
                      e1.type <> e2.type
WHERE     (e1.type = 'P') AND (e2.type <> 'C')
GO

