-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[model_code_to_model]
(
	@ModelCode varchar(3)
)
RETURNS varchar(20)
AS
BEGIN
	RETURN CASE
		WHEN @ModelCode = '8VS' THEN 'A3 Limousine'
		WHEN @ModelCode = '8VM' THEN 'A3 Limousine'
		WHEN @ModelCode = '4GF' THEN 'A7'
		ELSE
			CASE LEFT(@ModelCode, 2)
				WHEN '8X' THEN 'A1'
				WHEN '8V' THEN 'A3'
				WHEN '8K' THEN 'A4'
				WHEN '8W' THEN 'A4'
				WHEN '8F' THEN 'A5'
				WHEN '8T' THEN 'A5'
				WHEN 'F5' THEN 'A5'
				WHEN '4G' THEN 'A6'
				WHEN '4H' THEN 'A8'
				WHEN '8U' THEN 'Q3'
				WHEN '8R' THEN 'Q5'
				WHEN 'FY' THEN 'Q5'
				WHEN '4L' THEN 'Q7'
				WHEN '4M' THEN 'Q7'
				WHEN '4S' THEN 'R8'
				WHEN '42' THEN 'R8'
				WHEN '8J' THEN 'TT'
				WHEN 'FV' THEN 'TT'
				WHEN 'GA' THEN 'Q2'
				ELSE LEFT(@ModelCode, 2)
			END
		END

END
GO

