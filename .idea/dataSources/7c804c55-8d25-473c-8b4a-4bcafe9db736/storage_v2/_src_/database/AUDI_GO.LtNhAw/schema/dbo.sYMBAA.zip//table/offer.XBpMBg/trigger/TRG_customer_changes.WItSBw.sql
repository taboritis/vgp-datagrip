CREATE TRIGGER [dbo].[TRG_customer_changes]
   ON  [dbo].[offer]
   AFTER UPDATE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    IF UPDATE(customer_id)
    BEGIN
		INSERT INTO [dbo].[customer_changes]
           ([offer_no]
           ,[customer_id_old]
           ,[customer_id_new])

        SELECT  i.offer_no, d.customer_id, i.customer_id
        FROM    inserted i
        INNER JOIN deleted d ON i.id=d.id
    END
END
GO

