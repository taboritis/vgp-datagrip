
CREATE PROCEDURE [dbo].[ImportFinancingAlgorithm]
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO financing_algorithm (code)
    SELECT impfa.code
	FROM _import_financing_algorithm impfa
	LEFT JOIN financing_algorithm fa ON fa.code = impfa.code
	WHERE fa.id IS NULL
END

GO

