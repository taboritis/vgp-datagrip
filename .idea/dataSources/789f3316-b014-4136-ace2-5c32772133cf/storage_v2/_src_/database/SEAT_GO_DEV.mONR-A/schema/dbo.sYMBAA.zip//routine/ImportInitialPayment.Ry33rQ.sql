
CREATE PROCEDURE [dbo].[ImportInitialPayment]
AS
BEGIN
	SET NOCOUNT ON;

    INSERT INTO initial_payment (financing_id, rate, isDefault)
    SELECT tmpf.new_id,
		impip.rate,
		impip.isDefault
	FROM _import_initial_payment impip
	JOIN dbo.#Financing tmpf ON tmpf.import_id = impip.financing_id
END

GO

