
CREATE PROCEDURE [dbo].[ProcessImportFinancing]
AS
BEGIN
	SET NOCOUNT ON;

    CREATE TABLE dbo.#Financing (   
		import_id int NOT NULL, 
		new_id int NOT NULL
	)

	BEGIN TRY
		BEGIN TRANSACTION
			EXEC dbo.ImportFinancingAlgorithm
			EXEC dbo.ImportFinancingCarModel
			EXEC dbo.ImportFinancing
			EXEC dbo.ImportInitialPayment
			EXEC dbo.ImportFinancingPeriod
			EXEC dbo.ImportMileageLimit

			INSERT INTO insurance_financing (insurance_id, financing_id)
			SELECT i.id, f.new_id
			FROM insurance i, #Financing f

			UPDATE uf
			SET uf.is_active = 0
			FROM #Financing newf
			JOIN financing f ON f.id = newf.new_id
			JOIN financing uf ON uf.name = f.name
				AND uf.id <> f.id
				AND uf.is_active = 1
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
	END CATCH

	DROP TABLE dbo.#Financing
END

GO

