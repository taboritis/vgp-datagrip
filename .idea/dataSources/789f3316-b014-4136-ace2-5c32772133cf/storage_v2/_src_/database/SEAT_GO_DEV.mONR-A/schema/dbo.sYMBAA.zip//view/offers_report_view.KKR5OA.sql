CREATE VIEW dbo.offers_report_view
AS
SELECT distinct o.id,o.offer_no, usa.username,usa.company_name, cu.name, co.model_name
	,(SELECT TOP(1) name FROM [SEAT_CCWS].[dbo].[view_version]
		WHERE full_code = SUBSTRING ( mc.motor_full_code ,0 , 5 )
		AND cache_repository_id = co.cache_repository_id
		AND local_id = co.version_id
		AND name IS NOT NULL
		)
	 AS version_name																
	,mc.motor_full_code AS model_code												
	,CAST(o.created as date) as created												
	,DATENAME(month, o.created) as month											
	,(SELECT TOP(1) vm.capacity ORDER BY vm.id DESC) AS capacity
	,(SELECT TOP(1) vm.power_ps ORDER BY vm.id DESC) AS power_ps
	,"transmission" = CASE 
						WHEN CHARINDEX('auto', vm.name COLLATE Latin1_General_CI_AS) > 0 THEN 'DSG'
						ELSE 'manualna'
					  END
	,"fuel type" =	CASE 
						WHEN vm.is_diesel = 1 THEN 'diesel'
						ELSE 'benzyna'
					  END
	,"drive" = CASE 
						WHEN CHARINDEX('4drive', vm.name COLLATE Latin1_General_CI_AS) > 0 THEN '4Drive'
						WHEN CHARINDEX('4wd', vm.name COLLATE Latin1_General_CI_AS) > 0 THEN '4Drive'
						ELSE 'front'
					  END
	,(select TOP(1) name FROM [SEAT_CCWS].[dbo].[view_interior]
		WHERE code = mc.interior_id
		AND cache_repository_id = co.cache_repository_id)
		AS interior,
	o.is_closed
	,mc.id as mc_id
	,equipment_id = STUFF((
		SELECT ',' + m.equipment_id AS 'data()'
		FROM motor_configuration_equipment m
		where m.motor_configuration_id=mce.motor_configuration_id
		FOR XML PATH('')), 1, 1, '') 
	,accessory_id = STUFF((
		SELECT ',' + m.accessory_id AS 'data()'
		FROM motor_configuration_accessory m
		where m.motor_configuration_id=mca.motor_configuration_id
		FOR XML PATH('')), 1, 1, '') 
FROM [SEAT_GO].[dbo].[offer] o
LEFT JOIN dbo.customer cu ON cu.id = o.customer_id
LEFT JOIN dbo.user_account usa ON usa.id = o.user_account_id
LEFT JOIN dbo.configuration_group cg ON cg.offer_id = o.id
LEFT JOIN dbo.configuration co ON co.configuration_group_id = cg.id
LEFT JOIN dbo.motor_configuration mc ON mc.configuration_id = co.id
LEFT JOIN dbo.motor_configuration_accessory mca ON mca.motor_configuration_id = mc.id
LEFT JOIN dbo.motor_configuration_equipment mce ON mce.motor_configuration_id = mc.id
INNER JOIN [SEAT_CCWS].[dbo].[view_motor] vm ON vm.full_code = mc.motor_full_code 
			AND vm.cache_repository_id = co.cache_repository_id
GO

