

/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [dbo].[view_vwfs_export_data] AS
SELECT 
	'A' AS brand_code
	,10000 + DENSE_RANK() OVER (ORDER BY cg.code ASC) AS model_group_carline
	,cg.name AS model_group_name
	,SUBSTRING(m.code,1,2) AS model_group_code
	,MIN(m.price) OVER (PARTITION BY cg.id) AS model_group_price
	,m.model_year AS model_group_model_year
	,100000 + DENSE_RANK() OVER (ORDER BY cg.code ASC, cl.code ASC)  AS model_sales_group
	,cl.name AS model_name
	,SUBSTRING(m.code,1,3) AS model_code
	,MIN(m.price) OVER (PARTITION BY cl.id) AS model_price
	,m.model_year AS model_model_year
	,NULL AS model_description
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/z1/') AS model_image
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/x3/') AS model_image_small
	,SUBSTRING(m.code,1,4) AS version_name
	,SUBSTRING(m.code,1,4) + '-' + CAST((100000 + DENSE_RANK() OVER (ORDER BY cg.code ASC, cl.code ASC)) AS VARCHAR) AS version_code
	,MIN(m.price) OVER (PARTITION BY SUBSTRING(m.code,0,4)) AS version_price
	,NULL AS version_description
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/z1/') AS version_image
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/x3/') AS version_image_small
	,m.name AS motor_name
	,m.code AS motor_code
	,m.price AS motor_price
	,m.fuel_type AS motor_fuel_type
	,m.power_km AS motor_power
	,m.name_short AS motor_short_name
	,m.gear +' '+m.gear_type AS motor_transmission_name
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/z1/') AS motor_image
	,REPLACE((SELECT TOP 1 [image_url] FROM [cis_exterior] ce WHERE ce.model_id = m.id),'/xm/','/x3/') AS motor_image_small
  FROM [cis] cis
  JOIN [cis_carlinegroup] cg ON cg.cis_id = cis.id
  JOIN [cis_carline] cl ON cl.carline_group_id = cg.id
  JOIN [cis_model] m ON m.carline_id = cl.id
  WHERE cis.date_end IS NULL AND cis.active = 1

go

