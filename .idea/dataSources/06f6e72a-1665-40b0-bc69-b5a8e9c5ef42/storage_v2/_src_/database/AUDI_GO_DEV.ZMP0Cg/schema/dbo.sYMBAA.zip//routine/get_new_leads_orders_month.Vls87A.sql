-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[get_new_leads_orders_month]
(	
	@Year int,
	@Month int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT *, 'orders' as value_type
	FROM (
		SELECT CAST(@Month as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,r.model
			,ISNULL(ISNULL(obm.number_of_offers, om.number_of_offers), 0) as number_of_orders
		FROM (
			SELECT *
			FROM _report r
			WHERE r.is_base = 0
		) r
		LEFT JOIN get_orders_base_month (@Year, @Month) obm ON obm.model = r.model
		LEFT JOIN get_orders_month (@Year, @Month) om ON om.model = r.model
	) x
	PIVOT (
		SUM(x.number_of_orders) FOR model IN (A1, A3, A4, A5, A6, A7, A8, Q3, Q5, Q7, R8, TT,
				[A3 Limousine], [A3 Sportback], [A4 Limousine], [A4 Avant], [A4 Allroad quattro],
				[A5 Coupe], [A5 Sportback], [A6 Limousine], [A6 Avant], [A6 Allroad]
		)
	) p
	UNION ALL
	SELECT *, 'leads' as value_type
	FROM (
		SELECT CAST(@Month as varchar(4)) + '''' + RIGHT(CAST(@Year as varchar(4)), 2) as week
			,r.model
			,ISNULL(ISNULL(obm.number_of_leads, om.number_of_leads), 0) as number_of_leads
		FROM (
			SELECT *
			FROM _report r
			WHERE r.is_base = 0
		) r
		LEFT JOIN get_new_leads_base_month (@Year, @Month) obm ON obm.model = r.model
		LEFT JOIN get_new_leads_month (@Year, @Month) om ON om.model = r.model
	) x
	PIVOT (
		SUM(x.number_of_leads) FOR model IN (A1, A3, A4, A5, A6, A7, A8, Q3, Q5, Q7, R8, TT,
				[A3 Limousine], [A3 Sportback], [A4 Limousine], [A4 Avant], [A4 Allroad quattro],
				[A5 Coupe], [A5 Sportback], [A6 Limousine], [A6 Avant], [A6 Allroad]
		)
	) p
)
go

