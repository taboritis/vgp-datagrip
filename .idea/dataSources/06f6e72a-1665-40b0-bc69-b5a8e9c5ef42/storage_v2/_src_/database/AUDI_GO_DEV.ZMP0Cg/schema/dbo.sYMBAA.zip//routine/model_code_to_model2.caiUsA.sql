
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[model_code_to_model2]
(
	@ModelCode varchar(3)
)
RETURNS varchar(20)
AS
BEGIN
	RETURN CASE @ModelCode
		WHEN '8VS' THEN 'A3 Limousine'
		WHEN '8VM' THEN 'A3 Limousine'
		WHEN '8VA' THEN 'A3 Sportback'
		WHEN '8VF' THEN 'A3 Sportback'
		WHEN '8W2' THEN 'A4 Limousine'
		WHEN '8K2' THEN 'A4 Limousine'
		WHEN '8W5' THEN 'A4 Avant'
		WHEN '8K5' THEN 'A4 Avant'
		WHEN '8KH' THEN 'A4 Allroad quattro'
		WHEN '8WH' THEN 'A4 Allroad quattro'
		WHEN '8T3' THEN 'A5 Coupe'
		WHEN 'F53' THEN 'A5 Coupe'
		WHEN '8TA' THEN 'A5 Sportback'
		WHEN 'F5A' THEN 'A5 Sportback'
		WHEN '4GC' THEN 'A6 Limousine'
		WHEN '4G2' THEN 'A6 Limousine'
		WHEN '4GD' THEN 'A6 Avant'
		WHEN '4G5' THEN 'A6 Avant'
		WHEN '4GJ' THEN 'A6 Allroad'
		WHEN '4GH' THEN 'A6 Allroad'
		ELSE NULL
	END

END

go

