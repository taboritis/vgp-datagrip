-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[get_new_leads_base_week]
(	
	@Year int,
	@Week int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT r.model
		,ISNULL(z.number_of_leads, 0) as number_of_leads
		,r.db_order
	FROM (
		SELECT model, db_order
		FROM _report
		WHERE is_base = 1
	) r
	LEFT JOIN (
		SELECT model, COUNT(1) as number_of_leads
		FROM (
			SELECT x.model, x.customer_id
			FROM (
				SELECT dbo.model_code_to_model(c.model_code) as model
					,o.customer_id as customer_id
					,o.finished_date as finished_date
				FROM configuration c
				JOIN offer o ON o.id = c.offer_id
				WHERE o.finished_date IS NOT NULL
			) x
			WHERE x.customer_id IS NOT NULL AND YEAR(x.finished_date) = @Year AND DATEPART(ISO_WEEK, x.finished_date) = @Week
			GROUP BY x.model, x.customer_id
		) y
		GROUP BY y.model
		UNION ALL
		SELECT 'Total', COUNT(1)
		FROM (
			SELECT x.customer_id
			FROM (
				SELECT dbo.model_code_to_model(c.model_code) as model
					,o.customer_id as customer_id
					,o.finished_date as finished_date
				FROM configuration c
				JOIN offer o ON o.id = c.offer_id
				WHERE o.finished_date IS NOT NULL
			) x
			WHERE x.customer_id IS NOT NULL AND YEAR(x.finished_date) = @Year AND DATEPART(ISO_WEEK, x.finished_date) = @Week
			GROUP BY x.customer_id
		) y
	) z ON r.model = z.model
)
go

